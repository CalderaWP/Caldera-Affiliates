# Caldera Affiliates

Easily swap out the name of an affiliate partner with your affiliate link.

Caldera Affiliates is a free plugin by [CalderaWP](https://CalderaWP.com).

### What It Does

Easily swap out the name of an affiliate partner with your affiliate link. Create one or more groups of affiliate links, and when you use the name of an affiliate in your post content this plugin will replace it with the link you specify.

Makes it easy to add, update and remove affiliate links you use on your site.

### License, Copyright etc.
Copyright 2015 [CalderaWP LLC](https://CalderaWP.com), [David Cramer](http://digilab.co.za/) & [Josh Pollock](http://JoshPress.net).

Licensed under the terms of the [GNU General Public License version 2](http://www.gnu.org/licenses/gpl-2.0.html) or later. Please share with your neighbor.
    
