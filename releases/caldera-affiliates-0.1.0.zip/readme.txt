=== Caldera Affiliates  ===
Contributors: Desertsnowman, Shelob9
Donate link: https://CalderaWP.com
Tags: affiliate, affiliates
Requires at least: 3.9
Tested up to: 4.2
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily swap out the name of an affiliate partner with your affiliate link.

== Description ==

Easily swap out the name of an affiliate partner with your affiliate link. Create one or more groups of affiliate links, and when you use the name of an affiliate in your post content this plugin will replace it with the link you specify.

Makes it easy to add, update and remove affiliate links you use on your site.

Caldera Affiliates is a free plugin by [CalderaWP](https://CalderaWP.com).

== Installation ==

Install the plugin through the WordPress Plugins Installer or upload `plugin-name.php` to the plugins directory of your content directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Does It Got To Eleven? =

Of course it does.

== Screenshots ==

1. Screenshot 1 description
2. Screenshot 2 description

== Changelog ==

= 0.1.0 =
Initial Version

== Upgrade Notice ==
Nothing to report
